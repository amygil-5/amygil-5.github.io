
# Welcome to LearnCS8 Resume Website

This is an template resume website built using Bootstrap. 

Follow the instructions on Lab 3 located at https://www.learncs8.com 

Special thanks to the open source bootstrap libraries that made this website possible.

If you have any problems, please reach out to support on the LearnCS8.com homepage.
